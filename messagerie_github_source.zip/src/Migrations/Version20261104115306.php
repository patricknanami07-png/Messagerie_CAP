<?php

declare(strict_types=1);

namespace App\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20261104115306 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE messages ADD attachment_filename VARCHAR(255) DEFAULT NULL');
        $this->addSql('ALTER TABLE messages ADD attachment_original_name VARCHAR(255) DEFAULT NULL');
        $this->addSql('ALTER TABLE messages ADD voice_filename VARCHAR(255) DEFAULT NULL');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE messages DROP attachment_filename');
        $this->addSql('ALTER TABLE messages DROP attachment_original_name');
        $this->addSql('ALTER TABLE messages DROP voice_filename');
    }
}
